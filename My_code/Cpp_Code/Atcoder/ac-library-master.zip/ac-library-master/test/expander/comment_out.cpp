// #include <atcoder/dsu>
/* #include <atcoder/dsu> */
/* #include <atcoder/dsu>
*/

namespace atcoder {
    struct dsu {

    };
}

int main() {
}
